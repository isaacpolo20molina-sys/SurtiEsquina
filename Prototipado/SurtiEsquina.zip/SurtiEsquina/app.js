let input = document.getElementById('contraseña');
let eyeIcon = document.getElementById('eye-icon');
let eyeOpen = document.getElementById('eye-open');
let eyeClosed = document.getElementById('eye-closed');

eyeIcon.addEventListener('click', function () {
    if (input.type === 'password') {
        input.type = 'text';
        eyeOpen.classList.add('d-none');
        eyeClosed.classList.remove('d-none');
        eyeIcon.setAttribute('aria-label', 'Ocultar contraseña');
    } else {
        input.type = 'password';
        eyeClosed.classList.add('d-none');
        eyeOpen.classList.remove('d-none');
        eyeIcon.setAttribute('aria-label', 'Mostrar contraseña');
    }
});
