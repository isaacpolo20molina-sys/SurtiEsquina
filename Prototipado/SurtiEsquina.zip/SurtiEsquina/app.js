let input = document.getElementById('contraseña');
let eyeIcon = document.getElementById('eye-icon');
let eyeOpen = document.getElementById('eye-open');
let eyeClosed = document.getElementById('eye-closed');

eyeIcon.addEventListener('click', function () {
    if (input.type === 'password') {
        input.type = 'text';
        eyeOpen.classList.add('d-none');
        eyeClosed.classList.remove('d-none');
        eyeIcon.setAttribute('aria-label', 'Ocultar contraseña');
    } else {
        input.type = 'password';
        eyeClosed.classList.add('d-none');
        eyeOpen.classList.remove('d-none');
        eyeIcon.setAttribute('aria-label', 'Mostrar contraseña');
    }
});

const buttons = document.querySelectorAll('.animacion_boton');

buttons.forEach(button => {

    button.addEventListener('mouseenter', () => {
        button.style.transform = 'translateY(-5px)';
    });

    button.addEventListener('mouseleave', () => {
        button.style.transform = 'translateY(0)';
    });

});

const form = document.querySelector('.needs-validation');

form.addEventListener('submit', function (event) {
    event.preventDefault();

    if (!form.checkValidity()) {
        form.classList.add('was-validated');
        return;
    }
    
    form.classList.remove('was-validated');
    Swal.fire({
        title: "Inicio de sesion, exitoso, redirigiendo al dashboard...",
        icon: "success",
        timer: 3000,
        timerProgressBar: true,
        showConfirmButton: false
    });
});