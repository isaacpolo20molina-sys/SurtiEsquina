//Tarjeta para registrar producto con JS
document.addEventListener("DOMContentLoaded", () => {

  const formulario = document.getElementById("formRegistrarProducto");
  const modalElemento = document.getElementById("modalRegistrarProducto");
  const contenedorProductos = document.getElementById("productosGrid");

  if (!formulario || !modalElemento || !contenedorProductos) {
    return;
  }

  formulario.addEventListener("submit", function (event) {

    event.preventDefault();

    // Validación de Bootstrap / navegador
    if (!formulario.checkValidity()) {
      formulario.reportValidity();
      return;
    }

    // Obtener valores de el formulario
    const nombre = document.getElementById("nombreProducto").value.trim();
    const categoria = document.getElementById("categoriaProducto").value;
    const marca = document.getElementById("marcaProducto").value.trim();

    const compra = Number(document.getElementById("precioCompra").value);
    const venta = Number(document.getElementById("precioVenta").value);

    const stock = Number(document.getElementById("stockInicial").value);
    const minimo = Number(document.getElementById("stockMinimo").value);

    const imagen = document.getElementById("imagenProducto").value.trim();
    const vencimiento = document.getElementById("fechaVencimiento").value;

    // Validar precio
    if (venta <= 0 || compra < 0) {
      Swal.fire({
        icon: "error",
        title: "Precios inválidos",
        text: "Verifica los precios ingresados.",
        confirmButtonColor: "#0B624B"
      });
      return;
    }

    // Validar existencias
    if (
      !Number.isInteger(stock) ||
      !Number.isInteger(minimo) ||
      stock < 0 ||
      minimo < 0
    ) {
      Swal.fire({
        icon: "error",
        title: "Existencias inválidas",
        text: "Las existencias deben ser números enteros positivos o cero.",
        confirmButtonColor: "#0B624B"
      });
      return;
    }

    // Evitar nombres duplicados en la demostración
    const productosExistentes = [
      ...contenedorProductos.querySelectorAll(".product-card")
    ];

    const duplicado = productosExistentes.some(producto =>
      producto.dataset.nombre.toLowerCase() === nombre.toLowerCase()
    );

    if (duplicado) {
      Swal.fire({
        icon: "warning",
        title: "Producto existente",
        text: "Ya existe un producto con ese nombre.",
        confirmButtonColor: "#0B624B"
      });
      return;
    }

    // Crear tarjeta
    const tarjeta = document.createElement("article");
    tarjeta.className = "product-card";

    tarjeta.dataset.nombre = nombre;
    tarjeta.dataset.categoria = categoria;
    tarjeta.dataset.estado = "activo";
    tarjeta.dataset.stock = stock;
    tarjeta.dataset.minimo = minimo;

    const formatoMoneda = new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
      maximumFractionDigits: 2
    });

    const imagenContenedor = document.createElement("div");
    imagenContenedor.className = "product-image";

    const estado = document.createElement("span");
    estado.className = "product-status";
    estado.textContent = "Activo";
    imagenContenedor.appendChild(estado);

    if (imagen) {
      const foto = document.createElement("img");
      foto.src = imagen;
      foto.alt = nombre;
      foto.style.width = "100%";
      foto.style.height = "100%";
      foto.style.objectFit = "contain";
      foto.style.padding = "15px";

      foto.onerror = () => {
        foto.remove();
        const placeholder = document.createElement("div");
        placeholder.className = "image-placeholder";
        placeholder.textContent = "Sin imagen";
        imagenContenedor.appendChild(placeholder);
      };

      imagenContenedor.appendChild(foto);

    } else {
      const placeholder = document.createElement("div");
      placeholder.className = "image-placeholder";
      placeholder.textContent = "Sin imagen";
      imagenContenedor.appendChild(placeholder);
    }

    const informacion = document.createElement("div");
    informacion.className = "product-info";

    const categoriaTexto = document.createElement("span");
    categoriaTexto.className = "product-category";
    categoriaTexto.textContent = categoria.toUpperCase();

    const titulo = document.createElement("h2");
    titulo.textContent = nombre;

    const detalles = document.createElement("div");
    detalles.className = "product-details";

    const detallePrecio = document.createElement("div");
    const etiquetaPrecio = document.createElement("span");
    etiquetaPrecio.className = "detail-label";
    etiquetaPrecio.textContent = "Precio de venta";

    const valorPrecio = document.createElement("strong");
    valorPrecio.textContent = formatoMoneda.format(venta);

    detallePrecio.append(etiquetaPrecio, valorPrecio);

    const detalleStock = document.createElement("div");
    const etiquetaStock = document.createElement("span");
    etiquetaStock.className = "detail-label";
    etiquetaStock.textContent = "Existencias";

    const valorStock = document.createElement("strong");
    valorStock.textContent = `${stock} unidades`;

    detalleStock.append(etiquetaStock, valorStock);
    detalles.append(detallePrecio, detalleStock);

    const acciones = document.createElement("div");
    acciones.className = "product-actions";

    const botonEditar = document.createElement("button");
    botonEditar.type = "button";
    botonEditar.className = "btn-edit";
    botonEditar.textContent = "Editar producto";
    botonEditar.disabled = true;
    botonEditar.title = "Edición pendiente de implementar";

    acciones.appendChild(botonEditar);

    informacion.append(categoriaTexto, titulo, detalles, acciones);
    tarjeta.append(imagenContenedor, informacion);

    // Guardar información adicional en memoria de la tarjeta
    tarjeta.dataset.marca = marca;
    tarjeta.dataset.precioCompra = compra;
    tarjeta.dataset.precioVenta = venta;
    tarjeta.dataset.imagen = imagen;
    tarjeta.dataset.vencimiento = vencimiento;

    // Agregar producto
    contenedorProductos.appendChild(tarjeta);

    // Actualizar contador de categoría
    const botonesCategoria = document.querySelectorAll(
      "#filtrosCategorias .filter-item"
    );

    botonesCategoria.forEach(boton => {
      const esTodas = boton.dataset.categoria === "Todas";
      const esCategoria = boton.dataset.categoria === categoria;

      if (esTodas || esCategoria) {
        const contador = boton.querySelector(".filter-count");

        if (contador) {
          contador.textContent = Number(contador.textContent) + 1;
        }
      }
    });

    // Actualizar contador de stock bajo
    if (stock <= minimo) {
      const contadorStock = document.querySelector(
        "#filtroStock .filter-count"
      );

      if (contadorStock) {
        contadorStock.textContent =
          Number(contadorStock.textContent) + 1;
      }
    }

    // Actualizar resultados visibles
    document.getElementById("buscarProducto")
      .dispatchEvent(new Event("input"));

    // Cerrar modal
    const instancia = bootstrap.Modal.getInstance(modalElemento);
    instancia?.hide();

    // Limpiar formulario
    formulario.reset();

    // Confirmación
    Swal.fire({
      icon: "success",
      title: "Producto registrado",
      text: `${nombre} fue agregado al catálogo.`,
      confirmButtonColor: "#0B624B"
    });

  });

});