
document.addEventListener("DOMContentLoaded", function () {

    const btnNuevo = document.getElementById("btnNuevoProveedor");
    const formulario = document.getElementById("formProveedor");
    const contenedor = document.getElementById("contenedorProveedores");
    const contador = document.getElementById("contadorProveedores");
    const inputBuscar = document.getElementById("buscarProveedor");
    const botonesFiltro = document.querySelectorAll(".btn-filtro");
    const modalElemento = document.getElementById("modalProveedor");

    const modal = new bootstrap.Modal(modalElemento);
    const claveAlmacenamiento = "proveedoresSurtiEsquina";

    const campos = {
        id: document.getElementById("idProveedor"),
        nit: document.getElementById("nitProveedor"),
        nombre: document.getElementById("nombreProveedor"),
        telefono: document.getElementById("telefonoProveedor"),
        contacto: document.getElementById("contactoProveedor"),
        correo: document.getElementById("correoProveedor"),
        direccion: document.getElementById("direccionProveedor"),
        estado: document.getElementById("estadoProveedor")
    };

    const tituloModal = document.getElementById("tituloModalProveedor");
    const btnGuardar = document.getElementById("btnGuardarProveedor");

    const proveedoresIniciales = [
        {
            id: "PROV-001",
            nit: "900123456-7",
            nombre: "Distribuciones La 14",
            telefono: "300 456 7890",
            contacto: "Camilo Torres",
            correo: "ventas@distribucionesla14.co",
            direccion: "Cra. 14 # 22-18",
            estado: "activo"
        },
        {
            id: "PROV-002",
            nit: "901234567-8",
            nombre: "Alimentos El Dorado",
            telefono: "310 555 1288",
            contacto: "Mariana López",
            correo: "pedidos@eldorado.co",
            direccion: "Calle 80 # 11-42",
            estado: "activo"
        },
        {
            id: "PROV-003",
            nit: "890987654-3",
            nombre: "Bebidas Nacionales",
            telefono: "315 778 9900",
            contacto: "Diego Rojas",
            correo: "comercial@bebidasnacionales.co",
            direccion: "Av. El Dorado # 68-20",
            estado: "inactivo"
        }
    ];

    let proveedores = cargarProveedores();
    let proveedorEnEdicion = null;
    let filtroActual = "todos";
    let graficaProveedores = null;

    function cargarProveedores() {
        try {
            const datos = localStorage.getItem(claveAlmacenamiento);

            if (datos === null) {
                return proveedoresIniciales.map(proveedor => ({ ...proveedor }));
            }

            const resultado = JSON.parse(datos);

            return Array.isArray(resultado)
                ? resultado
                : proveedoresIniciales.map(proveedor => ({ ...proveedor }));

        } catch (error) {
            console.error("Error al cargar proveedores:", error);
            return proveedoresIniciales.map(proveedor => ({ ...proveedor }));
        }
    }

    function guardarProveedores() {
        try {
            localStorage.setItem(
                claveAlmacenamiento,
                JSON.stringify(proveedores)
            );

            return true;

        } catch (error) {
            console.error("Error al guardar proveedores:", error);

            Swal.fire({
                title: "Error de almacenamiento",
                text: "No fue posible guardar los cambios en el navegador.",
                icon: "error",
                confirmButtonColor: "#1F6A4C"
            });

            return false;
        }
    }

    function generarId() {
        const numeros = proveedores.map(proveedor => {
            const numero = Number(
                String(proveedor.id).replace("PROV-", "")
            );

            return Number.isFinite(numero) ? numero : 0;
        });

        const mayor = Math.max(0, ...numeros);

        return "PROV-" + String(mayor + 1).padStart(3, "0");
    }

    function escaparHTML(valor) {
        return String(valor ?? "").replace(/[&<>"']/g, caracter => {
            const caracteres = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            };

            return caracteres[caracter];
        });
    }

    function actualizarIconos() {
        if (typeof lucide !== "undefined") {
            lucide.createIcons();
        }
    }

    function obtenerProveedoresFiltrados() {
        const busqueda = inputBuscar.value.trim().toLowerCase();

        return proveedores.filter(proveedor => {
            const camposBusqueda = [
                proveedor.nombre,
                proveedor.id,
                proveedor.nit,
                proveedor.contacto
            ];

            const coincideBusqueda = camposBusqueda.some(campo =>
                String(campo ?? "").toLowerCase().includes(busqueda)
            );

            const coincideEstado =
                filtroActual === "todos" ||
                proveedor.estado === filtroActual;

            return coincideBusqueda && coincideEstado;
        });
    }

    function crearTarjeta(proveedor) {
        const inactivo = proveedor.estado === "inactivo";

        const tarjeta = document.createElement("article");

        tarjeta.className =
            "tarjeta-proveedor" + (inactivo ? " inactivo" : "");

        tarjeta.dataset.id = proveedor.id;

        tarjeta.innerHTML = `
            <div class="tarjeta-superior">
                <div class="icono-tienda">
                    <i data-lucide="store"></i>
                </div>

                <span class="estado ${inactivo
                    ? "estado-inactivo"
                    : "estado-activo"}">
                    ● ${inactivo ? "Inactivo" : "Activo"}
                </span>
            </div>

            <div class="tarjeta-identidad">
                <span class="codigo-proveedor">
                    ${escaparHTML(proveedor.id)}
                </span>

                <h2>${escaparHTML(proveedor.nombre)}</h2>

                <p>NIT ${escaparHTML(proveedor.nit)}</p>
            </div>

            <div class="tarjeta-contacto">
                <p>
                    <i data-lucide="user-round"></i>
                    <span>${escaparHTML(proveedor.contacto)}</span>
                </p>

                <p>
                    <i data-lucide="phone"></i>
                    <span>${escaparHTML(proveedor.telefono)}</span>
                </p>

                <p>
                    <i data-lucide="mail"></i>
                    <span>${escaparHTML(proveedor.correo)}</span>
                </p>

                <p>
                    <i data-lucide="map-pin"></i>
                    <span>${escaparHTML(proveedor.direccion)}</span>
                </p>
            </div>

            <div class="tarjeta-acciones">
                <button
                    type="button"
                    class="btn-editar"
                    data-id="${escaparHTML(proveedor.id)}"
                >
                    <i data-lucide="pencil"></i>
                    <span>Editar</span>
                </button>

                <button
                    type="button"
                    class="btn-estado"
                    data-id="${escaparHTML(proveedor.id)}"
                >
                    ${inactivo ? "Activar" : "Desactivar"}
                </button>
            </div>
        `;

        return tarjeta;
    }

    function mostrarSinResultados() {
        contenedor.innerHTML = `
            <div class="sin-resultados">
                <div class="sin-resultados-icono">
                    <i data-lucide="search-x"></i>
                </div>

                <h3>No se encontraron proveedores</h3>

                <p>
                    Intenta con otro nombre, ID, NIT
                    o cambia el filtro seleccionado.
                </p>
            </div>
        `;
    }


function actualizarEstadisticas() {

    const totalActivos = proveedores.filter(
        proveedor => proveedor.estado === "activo"
    ).length;

    const totalInactivos = proveedores.filter(
        proveedor => proveedor.estado === "inactivo"
    ).length;

    const totalGeneral = proveedores.length;

    document.getElementById("totalActivos").textContent = totalActivos;
    document.getElementById("totalInactivos").textContent = totalInactivos;
    document.getElementById("totalGeneral").textContent = totalGeneral;

    const canvas = document.getElementById("graficaProveedores");

    if (!canvas || typeof Chart === "undefined") {
        return;
    }

    if (graficaProveedores) {

        graficaProveedores.data.datasets[0].data = [
            totalActivos,
            totalInactivos
        ];

        graficaProveedores.update();

        return;
    }

    graficaProveedores = new Chart(canvas, {

        type: "doughnut",

        data: {
            labels: [
                "Activos",
                "Inactivos"
            ],

            datasets: [{
                label: "Proveedores",

                data: [
                    totalActivos,
                    totalInactivos
                ],

                backgroundColor: [
                    "#3FAF7A",
                    "#B77955"
                ],

                borderColor: "#F6F4EC",
                borderWidth: 4,
                hoverOffset: 8
            }]
        },

        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: "68%",

            plugins: {
                legend: {
                    position: "bottom",

                    labels: {
                        color: "#153F32",
                        padding: 20,
                        usePointStyle: true,

                        font: {
                            family: "Work Sans",
                            size: 13,
                            weight: "600"
                        }
                    }
                },

                tooltip: {
                    callbacks: {
                        label: function(contexto) {

                            const cantidad = contexto.parsed;

                            const porcentaje = totalGeneral > 0
                                ? ((cantidad / totalGeneral) * 100).toFixed(1)
                                : "0.0";

                            return ` ${cantidad} proveedores (${porcentaje}%)`;
                        }
                    }
                }
            }
        }
    });
}

    function actualizarContador(cantidad) {
        contador.textContent =
            cantidad + (cantidad === 1
                ? " proveedor"
                : " proveedores");
    }

    function mostrarProveedores() {
        const filtrados = obtenerProveedoresFiltrados();

        contenedor.innerHTML = "";

        if (filtrados.length === 0) {
            mostrarSinResultados();
        } else {
            filtrados.forEach(proveedor => {
                contenedor.appendChild(crearTarjeta(proveedor));
            });
        }

        actualizarContador(filtrados.length);
actualizarEstadisticas();
actualizarIconos();
    }

    function limpiarFormulario() {
        formulario.reset();
        proveedorEnEdicion = null;
    }

    function abrirRegistro() {
        limpiarFormulario();

        campos.id.value = generarId();
        campos.estado.value = "activo";

        tituloModal.textContent = "Nuevo proveedor";
        btnGuardar.textContent = "Registrar proveedor";

        modal.show();
    }

    function abrirEdicion(id) {
        const proveedor = proveedores.find(item => item.id === id);

        if (!proveedor) return;

        proveedorEnEdicion = proveedor.id;

        campos.id.value = proveedor.id;
        campos.nit.value = proveedor.nit;
        campos.nombre.value = proveedor.nombre;
        campos.telefono.value = proveedor.telefono;
        campos.contacto.value = proveedor.contacto;
        campos.correo.value = proveedor.correo;
        campos.direccion.value = proveedor.direccion;
        campos.estado.value = proveedor.estado;

        tituloModal.textContent = "Editar proveedor";
        btnGuardar.textContent = "Guardar cambios";

        modal.show();
    }

    function obtenerDatosFormulario() {
        return {
            id: campos.id.value.trim(),
            nit: campos.nit.value.trim(),
            nombre: campos.nombre.value.trim(),
            telefono: campos.telefono.value.trim(),
            contacto: campos.contacto.value.trim(),
            correo: campos.correo.value.trim(),
            direccion: campos.direccion.value.trim(),
            estado: campos.estado.value
        };
    }

    function validarNit(proveedor) {
        return !proveedores.some(item =>
            item.nit.toLowerCase() === proveedor.nit.toLowerCase() &&
            item.id !== proveedorEnEdicion
        );
    }

    async function guardarFormulario(evento) {
        evento.preventDefault();

        if (!formulario.reportValidity()) return;

        const datos = obtenerDatosFormulario();

        if (!validarNit(datos)) {
            await Swal.fire({
                title: "NIT duplicado",
                text: "Ya existe un proveedor registrado con este NIT.",
                icon: "warning",
                confirmButtonColor: "#1F6A4C"
            });

            return;
        }

        const esEdicion = proveedorEnEdicion !== null;

        const copiaAnterior = proveedores.map(item => ({ ...item }));

        if (esEdicion) {
            const indice = proveedores.findIndex(
                item => item.id === proveedorEnEdicion
            );

            if (indice === -1) return;

            proveedores[indice] = datos;

        } else {
            datos.id = generarId();
            proveedores.push(datos);
        }

        if (!guardarProveedores()) {
            proveedores = copiaAnterior;
            return;
        }

        mostrarProveedores();
        modal.hide();

        await Swal.fire({
            title: esEdicion
                ? "¡Proveedor actualizado!"
                : "¡Proveedor registrado!",

            text: esEdicion
                ? "Los cambios se guardaron correctamente."
                : "El proveedor se agregó correctamente.",

            icon: "success",
            confirmButtonColor: "#1F6A4C"
        });

        proveedorEnEdicion = null;
    }

    async function cambiarEstado(id) {
        const proveedor = proveedores.find(item => item.id === id);

        if (!proveedor) return;

        const estaActivo = proveedor.estado === "activo";
        const accion = estaActivo ? "desactivar" : "activar";

        const resultado = await Swal.fire({
            title: `¿Deseas ${accion} este proveedor?`,
            text: proveedor.nombre,
            icon: "question",
            showCancelButton: true,
            confirmButtonText: estaActivo
                ? "Sí, desactivar"
                : "Sí, activar",
            cancelButtonText: "Cancelar",
            confirmButtonColor: "#1F6A4C",
            cancelButtonColor: "#8A9B94"
        });

        if (!resultado.isConfirmed) return;

        const estadoAnterior = proveedor.estado;

        proveedor.estado = estaActivo ? "inactivo" : "activo";

        if (!guardarProveedores()) {
            proveedor.estado = estadoAnterior;
            return;
        }

        mostrarProveedores();

        await Swal.fire({
            title: "Estado actualizado",
            text: `El proveedor fue ${estaActivo
                ? "desactivado"
                : "activado"} correctamente.`,
            icon: "success",
            confirmButtonColor: "#1F6A4C"
        });
    }

    function buscarProveedores() {
        mostrarProveedores();
    }

    function seleccionarFiltro(boton) {
        botonesFiltro.forEach(item => {
            item.classList.remove("activo");
        });

        boton.classList.add("activo");

        filtroActual = boton.dataset.filtro;

        mostrarProveedores();
    }

    function manejarAccionesTarjetas(evento) {
        const botonEditar = evento.target.closest(".btn-editar");
        const botonEstado = evento.target.closest(".btn-estado");

        if (botonEditar) {
            abrirEdicion(botonEditar.dataset.id);
            return;
        }

        if (botonEstado) {
            cambiarEstado(botonEstado.dataset.id);
        }
    }

    function inicializarEventos() {
        btnNuevo.addEventListener("click", abrirRegistro);

        formulario.addEventListener("submit", guardarFormulario);

        contenedor.addEventListener(
            "click",
            manejarAccionesTarjetas
        );

        inputBuscar.addEventListener("input", buscarProveedores);

        botonesFiltro.forEach(boton => {
            boton.addEventListener("click", function () {
                seleccionarFiltro(this);
            });
        });

        modalElemento.addEventListener("hidden.bs.modal", function () {
            limpiarFormulario();
        });
    }

    function inicializarAplicacion() {
        inicializarEventos();
        mostrarProveedores();
    }

    inicializarAplicacion();

});
