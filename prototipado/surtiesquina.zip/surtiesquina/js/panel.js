// El panel usa enlaces HTML; no necesita librerías JavaScript.
